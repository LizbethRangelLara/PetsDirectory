export interface Pet {
    id: number;
    species: string;
    name: string;
    age: number;
    color: string;
    coat: string;
}